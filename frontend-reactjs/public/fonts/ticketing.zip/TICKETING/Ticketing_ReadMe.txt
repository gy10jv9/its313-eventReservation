
=== TICKETING ===

Keith Bates / K-Type © 2011 (version 1.01)
www.k-type.com    -    info@k-type.com

Ticketing is a monospaced font loosely based on the pixel style lettering of electronic ticketing, designed for clarity when cheaply printed at small sizes. Ticketing, however, has a larger x-height than is often found on ticket type.The glyphs were drawn on a square grid 13 wide by 22 high, though some accented characters are taller or extend below the baseline. The Space is a full character width, but the Non-Breaking Space is set to half the width of the glyphs.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------